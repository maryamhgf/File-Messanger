#include<iostream>
#include<vector>
#include<fstream>
#include<string>
#include <algorithm> 
#include <cctype>
#include <locale>

//getting current directory:
#include <stdio.h>  /* defines FILENAME_MAX */
// #define WINDOWS  /* uncomment this line to use it for windows.*/ 
#ifdef WINDOWS
#include <direct.h>
#define GetCurrentDir _getcwd
#else
#include <unistd.h>
#define GetCurrentDir getcwd
#endif
//
//getting name of files
#include <dirent.h>
#include <sys/types.h>
#include<string>
//
using namespace std;


//function1:
int Number_Of_Lines(string filename){
	
	ifstream fin;
	fin.open("people.txt", ios::in);

	char my_character ;
	int number_of_lines = 0;

	while (!fin.eof() ) {

		fin.get(my_character);
		if (my_character == '\n'){
			number_of_lines= number_of_lines+1;
		}

	}
	return number_of_lines+1;
}

//function2:
vector< vector<int> > Reading_File(){
	ifstream fin2;
	int number_of_lines;
	number_of_lines= Number_Of_Lines("people.txt");
	vector<int> temp;
	char my_character;
	vector< vector<int> > vect(number_of_lines);
	int NN= 0;
	fin2.open("people.txt", ios::in);
	while (!fin2.eof()) {
		fin2.get(my_character);
		if((int(my_character)-48)>=0){
			vect[NN].push_back(int(my_character)-48);
		}

		if(my_character=='\n'){
			
			NN= NN+1;	
			
		}
	}
	return vect;

}

//function3:
vector<string> removeDupWord(string str) 
{ 
   string word = ""; 
   vector<string> vect;
   int i=0;
   for (auto x : str) 
   { 
       if (x == ' ' && i<=1) 
       { 
           
           vect.push_back(word);
           i= i+1;
           word = ""; 
       } 
       else
       { 
           word = word + x; 
       } 
   }  
   
   vect.push_back(word); 
   return vect;
}

//function4:
int Storing_Messages(string ID, string senderID, string message){
	string name= ID+".txt";
	ofstream outfile;
	outfile.open(name, std::ofstream::out | std::ofstream::app);

	outfile <<senderID<<" "<< message<< endl;

	outfile.close();
	cout<<"sent"<<endl;
}

//function5:
int Show(string ID){
  ifstream fin;
  string fname;
  fname= ID+".txt";
  fin.open(fname, ios::in);
  string fline;
  while(!fin.eof()){
  	getline(fin, fline);
  	if(fline.empty()){

  		break;
  	}
  	cout<< fline<<endl;
  	}

}

//function6:
static inline void rtrim(std::string &s) {
    s.erase(std::find_if(s.rbegin(), s.rend(), [](int ch) {
        return !std::isspace(ch);
    }).base(), s.end());
}
//functon7:
int ERROR(int senderID, int receiverID){
	//cheching error:
	vector< vector<int> > Inf_People;
	Inf_People= Reading_File(); 
  	int i;
  	int flag_error1=0;
  	int flag_error2=0;
  	int flag_sender= 1;
  	int flag_receiver= 1;
  	for(i=0; i<Inf_People.size(); i++){
  		
  		//checking valid sender:
  		if(senderID== Inf_People[i][0]){
  			
  			flag_sender= 0;
  		}
  		//checking valid receiver:
  		if(receiverID== Inf_People[i][0]){
  					
  			flag_receiver= 0;
  		}
  		
  	
  	}
  	
  	
  	if(flag_sender==0 && flag_receiver==0){
  		if(Inf_People[senderID].size()==1){
  			flag_error1= 1;
  		}
  		else{
  			//checking possibility of sending message:
  			for(i=1; i<Inf_People[senderID].size(); i++){
  					
  				if(receiverID== Inf_People[senderID][i]){
  					flag_error1=0;
  					break;
  				}
  				else{
  						
  					flag_error1=1;
  					
  				}
  			}
  		}
  		if(flag_error1==1){
  			if(Inf_People[receiverID].size()==1){
  				flag_error2= 1;
  			}
  			else{
  				for(i=1; i<Inf_People[receiverID].size(); i++){
  					if(senderID== Inf_People[receiverID][i]){

  						flag_error1= 0;
  						flag_error2=0;
  						
  						break;
  					}
  					else{
  						
  						flag_error2=1;
  					}
  				}
  			}
  		}
  	}
  	if(flag_error1== 0 && flag_error2== 0 && flag_sender==0 && flag_receiver== 0){
  		return 0;
  	}
  	else{
  		return 1;
  	}

}
//function7:
int valid_user(int ID){
	vector< vector<int> > Inf_People;
	Inf_People= Reading_File(); 
  	int i;
  	int flag= 1;
  	
  	for(i=0; i<Inf_People.size(); i++){
  		
  		//checking valid sender:
  		if(ID== Inf_People[i][0]){
  			
  			flag= 0;
  		}
  		
  	
  	}
  	return flag;

}


//main:
int main(){
	//reding people.txt:
	vector< vector<int> > Inf_People;
	Inf_People= Reading_File(); 
	//getting inputs from user:
	string name;
  char temp;
    while(1){
  		if(!getline (cin,name)){
        break;
      }
      
  		vector<string> INPUT_VECT;
  		INPUT_VECT=removeDupWord(name);
  		//cout<<"size of input"<<INPUT_VECT.size()<<endl;
  		if(INPUT_VECT.size()==1 ){
  		
  			if(INPUT_VECT[0].empty() ){
  				break;
  			}
  			cout<<"failed"<<endl;
  			continue;
  		}
  		if(INPUT_VECT[0]== "show_msg"){
  			if(INPUT_VECT[1]==""){
          cout<<"failed"<<endl;
          continue;
        }
  			int ID= stoi(INPUT_VECT[1]);
  			int err_show= valid_user(ID);
  			if(err_show== 0){
  				Show(INPUT_VECT[1]);
  			}
  			else{
  				
  				cout<<"failed"<<endl;
  			}
  		}
  	
  		else if(INPUT_VECT.size()==3){
  			int senderID = stoi(INPUT_VECT[0]);
  			int receiverID= stoi(INPUT_VECT[1]);

  		int err= ERROR(senderID, receiverID);
  		if(err==0){
  			string Message= INPUT_VECT[2];
  			rtrim(Message);
  			Storing_Messages(INPUT_VECT[1], INPUT_VECT[0], Message);
  		}
  		else{
  			
  			cout<<"failed" << endl;
  		}

  			
		}
		else{
			
			cout<<"failed"<<endl;
		}
	}
}